<template>
  <div>
      <ul>
          <li>sidebar</li>
      </ul>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>